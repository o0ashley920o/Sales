const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');

const Sale = sequelize.define('Sale', {
  products: { type: DataTypes.JSON }, // [{productId, quantity, price}]
  customerId: { type: DataTypes.INTEGER },
  employeeId: { type: DataTypes.INTEGER },
  total: { type: DataTypes.FLOAT },
  date: { type: DataTypes.DATE }
});

module.exports = Sale;