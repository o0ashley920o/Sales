const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');

const Employee = sequelize.define('Employee', {
  name: { type: DataTypes.STRING, allowNull: false }
});

module.exports = Employee;