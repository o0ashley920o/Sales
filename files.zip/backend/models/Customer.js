const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');

const Customer = sequelize.define('Customer', {
  name: { type: DataTypes.STRING, allowNull: false },
  group: { type: DataTypes.STRING },
  credit: { type: DataTypes.FLOAT, defaultValue: 0 },
  pricingOverrides: { type: DataTypes.JSON }
});

module.exports = Customer;