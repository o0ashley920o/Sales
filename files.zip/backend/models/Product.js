const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');

const Product = sequelize.define('Product', {
  name: { type: DataTypes.STRING, allowNull: false },
  type: { type: DataTypes.ENUM('Ice', 'Green', 'Gear'), allowNull: false },
  costPrice: { type: DataTypes.FLOAT, allowNull: false },
  salePrice: { type: DataTypes.FLOAT, allowNull: false }
});

module.exports = Product;