import React from 'react';

function App() {
  return (
    <div>
      <h1>Home Business Management App</h1>
      <p>Welcome to your dashboard.</p>
      {/* Add navigation and main page components here */}
    </div>
  );
}

export default App;