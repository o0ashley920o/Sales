# Home Business Management App Requirements

## Goal
Comprehensive app for selling Ice, Green, and Gear products.

## Core Features

### Product Management
- Add, edit, delete products (Ice, Green, Gear)
- Set cost and sale price

### Sales Tracking
- Log sales transactions
- **Employee Sales Tracking**: Assign sales to employees, summarize by employee

### Customer Management
- Add/edit customers
- **Customer Groups**: Assign customers to groups
- **Credit Tracking**: Display current credit, log credit changes
- **Pricing Options**:
  - Set individual/group pricing
  - Discount by % or $ amount per group/customer
  - Override line item price at checkout

### Checkout
- Standard workflow
- Line item price override (manual input)
- Apply discounts (group/customer, %/$)
- Assign transaction/sale to employee

### Financial Overview
- Profit margin calculations
- Revenue analytics

### Reporting
- Credit report export (CSV)
- Employee sales report
- Customer sales history

### Dashboard
- Sales summary
- Quick stats (profit, outstanding credit, top customers/employees)

## Technical
- Responsive design (desktop/mobile)
- Professional, business-style UI
- Modern stack: React + Node.js + PostgreSQL

## Future Enhancements
- Inventory management
- Notifications (credit limits, low stock)
- Integrations (accounting, payment gateways)