# Home Business Management App

A comprehensive business management app for your home business selling Ice, Green, and Gear products.

## Stack
- Frontend: React
- Backend: Node.js/Express
- Database: PostgreSQL

## Features
- Product, customer, and employee management
- Individual/group pricing, discounts, credit tracking
- Sales tracking, analytics, exportable reports

See `docs/requirements.md` for detailed specifications.